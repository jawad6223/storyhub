<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">
   <!-- Mirrored from themesbrand.com/velzon/html/default/dashboard-analytics.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Feb 2023 15:33:36 GMT -->
   <head>
      <meta charset="utf-8" />
      <title>Analytics | Velzon - user & Dashboard Template</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta content="Premium Multipurpose user & Dashboard Template" name="description" />
      <meta content="Themesbrand" name="author" />
      <?php echo $__env->make('user.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </head>
   <body>
      <!-- Begin page -->
      <div id="layout-wrapper">
      <?php echo $__env->make('user.includes.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- removeNotificationModal -->
      <div id="removeNotificationModal" class="modal fade zoomIn" tabindex="-1" aria-hidden="true">
         <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="NotificationModalbtn-close"></button>
               </div>
               <div class="modal-body">
                  <div class="mt-2 text-center">
                     <lord-icon src="https://cdn.lordicon.com/gsqxdxog.json" trigger="loop" colors="primary:#f7b84b,secondary:#f06548" style="width:100px;height:100px"></lord-icon>
                     <div class="mt-4 pt-2 fs-15 mx-4 mx-sm-5">
                        <h4>Are you sure ?</h4>
                        <p class="text-muted mx-4 mb-0">Are you sure you want to remove this Notification ?</p>
                     </div>
                  </div>
                  <div class="d-flex gap-2 justify-content-center mt-4 mb-2">
                     <button type="button" class="btn w-sm btn-light" data-bs-dismiss="modal">Close</button>
                     <button type="button" class="btn w-sm btn-danger" id="delete-notification">Yes, Delete It!</button>
                  </div>
               </div>
            </div>
            <!-- /.modal-content -->
         </div>
         <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
      <!-- ========== App Menu ========== -->
      <div class="app-menu navbar-menu">
         <!-- LOGO -->
         <div class="navbar-brand-box">
            <!-- Dark Logo-->
            <a href="index.html" class="logo logo-dark">
            <span class="logo-sm">
            <img src="<?php echo e(asset('public/assets/images/logo-sm.png')); ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
            <img src="<?php echo e(asset('public/assets/images/logo-dark.png')); ?>" alt="" height="17">
            </span>
            </a>
            <!-- Light Logo-->
            <a href="index.html" class="logo logo-light">
            <span class="logo-sm">
            <img src="<?php echo e(asset('public/assets/images/logo-sm.png')); ?>" alt="" height="22">
            </span>
            <span class="logo-lg">
            <img src="<?php echo e(asset('public/assets/images/logo-light.png')); ?>" alt="" height="17">
            </span>
            </a>
            <button type="button" class="btn btn-sm p-0 fs-20 header-item float-end btn-vertical-sm-hover" id="vertical-hover">
            <i class="ri-record-circle-line"></i>
            </button>
         </div>
         <div id="scrollbar">
            <?php echo $__env->make('user.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Sidebar -->
         </div>
         <div class="sidebar-background"></div>
      </div>
      <!-- Left Sidebar End -->
      <!-- Vertical Overlay-->
      <div class="vertical-overlay"></div>
      <!-- ============================================================== -->
      <!-- Start right Content here -->
      <!-- ============================================================== -->
      <div class="main-content">
      <div class="page-content">
         <div class="container-fluid">
         <div class="row">
            <div class="col-12">
               <div class="page-title-box d-sm-flex align-items-center justify-content-between">
               </div>
            </div>
         </div>
            <div class="profile-foreground position-relative mx-n4 mt-n4">
               <div class="profile-wid-bg">
                  <img src="<?php echo e(asset('public/assets/images/profile-bg.jpg')); ?>" alt="" class="profile-wid-img" />
               </div>
            </div>
            <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
               <div class="row g-4">
                  <div class="col-auto">
                     <div class="avatar-lg">
                        <img src="<?php echo e(asset('storage/app/' . $user->image)); ?>" alt="user-img" class="img-thumbnail rounded-circle" />
                     </div>
                  </div>
                  <!--end col-->
                  <div class="col">
                     <div class="p-2">
                        <h3 class="text-white mb-1"><?php echo e($user->name); ?></h3>
                        <p class="text-white-75"><?php echo e($user->user_name); ?></p>
                        <div class="hstack text-white-50 gap-1"> 
                           <div class="me-2"><i class="ri-mail-open-line me-1 text-white-75 fs-16 align-middle"></i><?php echo e($user->email); ?></div>
                           <div>
                              <i class="ri-phone-line me-1 text-white-75 fs-16 align-middle"></i><?php echo e($user->contact); ?>

                           </div>
                        </div>
                     </div>
                  </div>
                  <!--end col-->
               </div>
               <!--end row-->
            </div>
            <div class="row">
               <div class="col-lg-12">
                  <div>
                     <div class="d-flex">
                        <!-- Nav tabs -->
                        <ul class="nav nav-pills animation-nav profile-nav gap-2 gap-lg-3 flex-grow-1" role="tablist">
                        </ul>
                        <div class="flex-shrink-0">
                        <a href="<?php echo e(url('user/add_story')); ?>" class="btn btn-success" ><i class="ri-file-history-fill align-bottom"></i> Share New Story</a>
                     
                           <a href="pages-profile-settings.html" class="btn btn-success" data-bs-toggle="modal" data-bs-target=".bs-example-modal-lg"><i class="ri-edit-box-line align-bottom"></i> Edit Profile</a>
                        </div>
                     </div>
                     <!-- Tab panes -->
                     <div class="tab-content pt-4 text-muted">
                        <div class="tab-pane active" id="overview-tab" role="tabpanel">
                           <div class="row">
                              <div class="col-xxl-4">
                                 <div class="card" style="height:150px;">
                                    <div class="card-body">
                                       <h3 class="card-title mb-4"  style="font-weight:700">Portfolio</h3>
                                       <hr>
                                       <div class="d-flex flex-wrap gap-3" >
                                          <div>
                                             <a href="<?php echo e($user->website); ?>" class="avatar-xs d-block" target="blank">
                                             <span class="avatar-title rounded-circle fs-16 bg-success">
                                             <i class="ri-global-fill"></i>
                                             </span>
                                             </a>
                                          </div>
                                          <div>
                                             <a href="<?php echo e($user->facebook); ?>" class="avatar-xs d-block" target="blank">
                                             <span class="avatar-title rounded-circle fs-16 bg-primary">
                                             <i class="ri-facebook-fill"></i>
                                             </span>
                                             </a>
                                          </div>
                                          <div>
                                             <a href="<?php echo e($user->twitter); ?>" class="avatar-xs d-block" target="blank">
                                             <span class="avatar-title rounded-circle fs-16 " style="background-color:#26a7de">
                                             <i class="ri-twitter-fill" style="background-color:#26a7de"></i>
                                             </span>
                                             </a>
                                          </div>
                                          <div>
                                             <a href="<?php echo e($user->linkedin); ?>" class="avatar-xs d-block" target="blank">
                                             <span class="avatar-title rounded-circle fs-16 " style="background-color:#0e76a8" >
                                             <i class=" ri-linkedin-fill"></i>
                                             </span>
                                             </a>
                                          </div>
                                       </div>
                                    </div>
                                    <!-- end card body -->
                                 </div>
                                 <!-- end card -->
                                 <!--  Large modal example -->
                                 <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                       <div class="modal-content">
                                          <div class="modal-header">
                                             <h5 class="modal-title" id="myLargeModalLabel">Edit Profile</h5>
                                             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                          </div>
                                          <div class="modal-body">
                                             <form class="card" action="<?php echo e(url('user/profile_edit_action')); ?>" method="post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden"  name="id"  value="<?php echo e($user->id); ?>">
                                                <div class="row">
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="firstnameInput" class="form-label">Name</label>
                                                         <input type="text" class="form-control"  name="name"  placeholder="Enter your name" value="<?php echo e($user->name); ?>">
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="firstnameInput" class="form-label"> User Name</label>
                                                         <input type="text" class="form-control"  name="user_name" placeholder="Enter your Username" value="<?php echo e($user->user_name); ?>">
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="firstnameInput" class="form-label">Image</label>
                                                         <input type="file" class="form-control"  name="image" >
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="phonenumberInput" class="form-label">Phone Number</label>
                                                         <input type="text" class="form-control"  placeholder="Enter your phone number" name="contact" value="<?php echo e($user->contact); ?>">
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="emailInput" class="form-label">Email Address</label>
                                                         <input type="email" class="form-control" id="emailInput" name="email" placeholder="Enter your email" value="<?php echo e($user->email); ?>">
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="firstnameInput" class="form-label">Website</label>
                                                         <input type="url" class="form-control" name="website"  placeholder="Enter your Website Url" value="<?php echo e($user->website); ?>">
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="phonenumberInput" class="form-label">Twitter</label>
                                                         <input type="url" class="form-control" name="twitter" placeholder="Enter your Twitter Url" value="<?php echo e($user->twitter); ?>">
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="emailInput" class="form-label">Facebook</label>
                                                         <input type="url" class="form-control" name="facebook"  placeholder="Enter your Fackbook Url" value="<?php echo e($user->facebook); ?>">
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-4">
                                                      <div class="mb-3">
                                                         <label for="emailInput" class="form-label">Linkedin</label>
                                                         <input type="url" class="form-control" name="linkedin" placeholder="Enter your Linkedin" value="<?php echo e($user->linkedin); ?>">
                                                      </div>
                                                   </div>
                                                   <div class="col-lg-12">
                                                      <div class="mb-3 pb-2">
                                                         <label for="exampleFormControlTextarea" class="form-label">Description</label>
                                                         <textarea class="form-control"  name="description" id="exampleFormControlTextarea" placeholder="Enter your description" rows="3"><?php echo e($user->description); ?>.</textarea>
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                   <div class="col-lg-12">
                                                      <div class="hstack gap-2 justify-content-end">
                                                         <button type="submit" class="btn btn-primary">Update</button>
                                                         <button type="button" class="btn btn-soft-success" data-bs-dismiss="modal">Cancel</button>
                                                      </div>
                                                   </div>
                                                   <!--end col-->
                                                </div>
                                                <!--end row-->
                                             </form>
                                          </div>
                                       </div>
                                       <!-- /.modal-content -->
                                    </div>
                                    <!-- /.modal-dialog -->
                                 </div>
                                 <!-- /.modal -->
                              </div>
                              <!--end col-->
                              <div class="col-xxl-8">
                                 <div class="card">
                                    <div class="card-body" style="height:150px;overflow: hidden;">
                                       <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <div class="alert alert-danger mb-2" id="hi" role="alert">
                                          <?php echo e($message); ?>

                                       </div>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <div class="alert alert-danger mb-2" id="hi" role="alert">
                                          <?php echo e($message); ?>

                                       </div>
                                       <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                       <h3 class="card-title mb-3" style="font-weight:700">Description</h3>
                                       <hr>
                                       <p><?php echo e($user->description); ?></p>
                                    </div>
                                    <!--end card-body-->
                                 </div>
                                 <!-- end card -->
                              </div>
                              <!--end col-->
                           </div>

                           
                           <!--end row-->
                        </div>
                     </div>
                     <!--end tab-content-->
                  </div>
               </div>
               <!--end col-->
            </div>

       
               

                     <?php $__currentLoopData = $story; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-lg-12">
                        <div class="card card-body">
                           <div class="d-flex mb-4 align-items-center">
                              <div class="flex-shrink-0">
                                 <img src="<?php echo e(asset('storage/app/' . $story->story_user->image)); ?>" alt="" class="avatar-sm rounded-circle" />
                              </div>
                              <div class="flex-grow-1 ms-2">
                                 <h5 class="card-title mb-1"><?php echo e($story->story_user->name); ?></h5>
                                 <p class="text-muted mb-0"><?php echo e($story->created_at); ?></p>
                              </div>
                              <div class="" style="float:right"  >
                                 <a href="<?php echo e(url('user/edit_story/'.$story->id)); ?>"> <i class="ri-edit-2-fill" style="color:green; font-size:20px"></i>  </a>
                                 <a href="<?php echo e(url('user/story_delete/'.$story->id)); ?>"><i class="ri-delete-bin-fill" style="color:red; font-size:18px"></i></a>  
                              </div>
                           </div>
                           <h5 class="mb-1"> <b></b><?php echo e($story->title); ?> </b> </h5>
                           <?php $des = Str::limit($story->description, 500); ?>
                           <p class="card-text text-muted">
                              <?php echo htmlspecialchars_decode(nl2br($des )); ?>

                           </p>
                           <div class="card-footer">
                           <?php if(!empty($story->linked_by)): ?>
                                       <a href="<?php echo e(url('user/story_detail/'.$story->linked_by)); ?>" class="link-success "><i class=" ri-links-line align-middle ms-1 lh-1"></i> View Reference story </a>
                                         <?php endif; ?>
                                          <a href="<?php echo e(url('user/story_detail/'.$story->id)); ?>" class="link-success float-end">Read More <i class="ri-arrow-right-s-line align-middle ms-1 lh-1"></i></a>
                                         
                                          <!-- <div id="basic-rater" dir="ltr"></div> -->
                                       </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                
                 
                  </div>
            <!--end row-->
         </div>
         <!-- container-fluid -->
      </div>
      <!-- End Page-content -->
      <!-- End Page-content -->
      <?php echo $__env->make('user.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php if(session('message1')): ?>
      <script>
         Swal.fire({
           position: 'top-end',
           icon: 'success',
           title: 'Successfully',
           showConfirmButton: false,
           timer: 2500
         })
      </script>
      <?php endif; ?>
      <script>
         $('#hi').delay(2000).slideUp(1200);
      </script>
   </body>
   <!-- Mirrored from themesbrand.com/velzon/html/default/dashboard-analytics.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Feb 2023 15:33:36 GMT -->
</html><?php /**PATH /home/u215930958/domains/storyhubhq.com/public_html/resources/views/user/profile.blade.php ENDPATH**/ ?>