<div class="container-fluid">

                    <div id="two-column-menu">
                    </div>
                    <ul class="navbar-nav" id="navbar-nav">
                        <li class="menu-title"><span data-key="t-menu">Menu</span></li>
                      
                            <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="<?php echo e(url('user/dashboard')); ?>">
                            <i class="ri-honour-line"></i> <span data-key="t-widgets">Dashboard</span>
                            </a>
                        </li> -->

                        </li> <!-- end Dashboard Menu -->

                       
                    


                  </li> <!-- end Dashboard Menu -->
                

                  <li class="nav-item">
                      <a class="nav-link menu-link" href="<?php echo e(url('user/view_story')); ?>">
                      <i class="ri-folder-history-fill"></i> <span data-key="t-authentication">Story Hub</span>
                 
                      </a>
                  </li>
                  <li class="nav-item">
                      <a class="nav-link menu-link" href="<?php echo e(url('user/profile')); ?>">
                      <i class="ri-account-circle-line"></i> <span data-key="t-authentication">Profile</span>
                 
                      </a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link menu-link" href="<?php echo e(url('user/add_story')); ?>">
                      <i class=" ri-file-history-fill"></i> <span data-key="t-apps">Share New Story</span>
                 
                      </a>
                  </li>


                  <li class="nav-item">
                      <a class="nav-link menu-link" href="<?php echo e(url('user/get_subscription')); ?>">
                      <i class="ri-price-tag-2-fill"></i> <span data-key="t-authentication">Get Subscription</span>
                 
                      </a>
                  </li>

                  <li class="nav-item">
                      <a class="nav-link menu-link" href="<?php echo e(url('user/logout')); ?>">
                      <i class="mdi mdi-logout"></i> <span data-key="t-authentication">logout</span>
                 
                      </a>
                  </li>

                        <!-- <li class="nav-item">
                            <a class="nav-link menu-link" href="#sidebarApps" data-bs-toggle="collapse" role="button" aria-expanded="false" aria-controls="sidebarApps">
                                <i class=" ri-file-history-fill"></i> <span data-key="t-apps">Story</span>
                            </a>
                            <div class="collapse menu-dropdown" id="sidebarApps">
                                <ul class="nav nav-sm flex-column">
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('user/add_story')); ?>" class="nav-link" data-key="t-calendar">Add Story</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(url('user/view_story')); ?>"class="nav-link" data-key="t-chat"> View Story </a>
                                    </li>
                                   
                               
                                </ul>
                            </div>
                        </li> -->

                      


                       


                    </ul>
                </div><?php /**PATH /home/u215930958/domains/storyhubhq.com/public_html/resources/views/user/includes/sidebar.blade.php ENDPATH**/ ?>