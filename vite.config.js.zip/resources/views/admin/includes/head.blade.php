 <!-- App favicon -->
 <link rel="shortcut icon" href="{{asset('public/assets/images/favicon.ico ')}}">

 
<!-- plugin css -->
<link href="{{asset('public/assetsassets/libs/jsvectormap/css/jsvectormap.min.css')}}" rel="stylesheet" type="text/css" />

<!-- Layout config Js -->
<script src="{{asset('public/assets/js/layout.js ')}}"></script>
<!-- Bootstrap Css -->
<link href="{{asset('public/assets/css/bootstrap.min.css ')}}" rel="stylesheet" type="text/css"  />
<!-- Icons Css -->
<link href="{{asset('public/assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="{{asset('public/assets/css/app.min.css')}}" rel="stylesheet" type="text/css" />
<!-- custom Css-->
<link href="{{asset('public/assets/css/custom.min.css')}}" rel="stylesheet" type="text/css" />

   <!-- quill css -->
   <link href="{{asset('public/assets/libs/quill/quill.core.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('public/assets/libs/quill/quill.bubble.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('public/assets/libs/quill/quill.snow.css')}}" rel="stylesheet" type="text/css" />


    
    <!-- dropzone min -->
    <script src="{{asset('public/assets/libs/dropzone/dropzone-min.js')}}"></script>
    <!-- filepond js -->
    <script src="{{asset('public/assets/libs/filepond/filepond.min.js')}}"></script>
    <script src="{{asset('public/assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.js')}}"></script>
    <script src="{{asset('public/assets/libs/filepond-plugin-file-validate-size/filepond-plugin-file-validate-size.min.js')}}"></script>
    <script src="{{asset('public/assets/libs/filepond-plugin-image-exif-orientation/filepond-plugin-image-exif-orientation.min.js')}}"></script>
    <script src="{{asset('public/assets/libs/filepond-plugin-file-encode/filepond-plugin-file-encode.min.js')}}"></script>
     <script src="{{asset('public/assets/js/pages/form-file-upload.init.js')}}"></script>


     <!-- dropzone css -->
    <link rel="stylesheet" href="{{asset('public/assets/libs/dropzone/dropzone.css')}}" type="text/css" />

<!-- Filepond css -->
<link rel="stylesheet" href="{{asset('public/assets/libs/filepond/filepond.min.css')}}" type="text/css" />
<link rel="stylesheet" href="{{asset('public/assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.css')}}">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.5/dist/sweetalert2.all.min.js"></script>
<script src="{{asset('public/assets/js/tinymce/tinymce.min.js')}}"></script>

<link rel="stylesheet" href="{{asset('public/assets/libs/glightbox/css/glightbox.min.css')}}">